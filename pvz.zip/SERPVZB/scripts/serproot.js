import{Player,Entity,EntityHealthComponent,EntityInventoryComponent,ItemStack,Dimension,ScoreboardObjective,world,system,ScriptEventSource}from"@minecraft/server";
import{ActionFormData}from"@minecraft/server-ui";
const ScoreboardAction={add:"add",remove:"remove",set:"set"};
function getScore(objectiveId,player){return world.scoreboard.getObjective(objectiveId).getScore(player.scoreboardIdentity);}
function setScore(entity,objectiveId,score, action){const objective=world.scoreboard.getObjective(objectiveId);if(!objective)throw new ReferenceError('Scoreboard objective does not exist in world.');const previousScore=!!entity.scoreboardIdentity?objective.getScore(entity.scoreboardIdentity):0;switch(action){case ScoreboardAction.add:score+=previousScore;break;case ScoreboardAction.remove:score-=previousScore;break;default:break;}if(!entity.scoreboardIdentity)entity.runCommand('scoreboard players set @s '+objective+' '+score);else {objective.setScore(entity.scoreboardIdentity, score);}};
function setScoreR(min,max){return Math.floor(Math.random()*(max-min+1))+min;}
function setDamage(entity,item){let du=item.getComponent("durability");if(du.damage<du.maxDurability){entity.runCommand(`replaceitem entity @s slot.weapon.mainhand 0 ${item.typeId} 1 ${du.damage+1}`);}else{entity.runCommand(`replaceitem entity @s slot.weapon.mainhand 0 air`);}}
let selected=0;
system.runInterval(()=>{try{for(const player of world.getPlayers()){let item=player.getComponent("inventory").container.getItem(player.selectedSlotIndex);if((item.typeId==="serp:screen_door"||item.typeId==="serp:newspaper")&&player.isSneaking){player.runCommand("effect @s resistance 1 5 true");}if(player.hasTag("ducky")&&player.isInWater&&player.isSneaking){player.applyKnockback(0,0,0,1);}}}catch{}},2);
system.afterEvents.scriptEventReceive.subscribe(event=>{try{let caller=event.sourceEntity;
  if(event.id==="serp:setplant"&&event.sourceType==ScriptEventSource.Entity){for(const plant of plants){if(getScore(`plant${caller.selected}`,caller)==plant.id&&getScore(`sun`,caller)>=plant.cost&&getScore(`timer${caller.selected}`,caller)<=0){caller.runCommand(`summon ${plant.name}`);setScore(caller,"sun",getScore("sun",caller)-plant.cost);setScore(caller,`timer${caller.selected}`,plant.time);}}}
}catch{}});
world.afterEvents.playerSpawn.subscribe(joined=>{try{let{player}=joined;if(player){if(!player.hasTag("started")){forms.start(player);player.runCommand("function start");}};}catch{}});
world.afterEvents.entitySpawn.subscribe(joined=>{try{let{entity}=joined;
  if(entity&&entity.typeId.startsWith("plant:")){entity.runCommand(`tp @s ${Math.floor(entity.location.x)} ${entity.location.y} ${Math.floor(entity.location.z)}`);}
  }catch{}});
world.beforeEvents.itemUse.subscribe(({source:player,itemStack:item})=>{switch(item.typeId){case "serp:phone":{if(!player.isSneaking){system.run(()=>forms.menu(player));}else{system.run(()=>forms.store(player));}};break;case "serp:pole":{if(player.isOnGround){system.run(()=>{const d=player.getViewDirection();player.applyKnockback(d.x,d.z,4,1);setDamage(player,item);});}};break;case "serp:jack_in_the_box":{system.run(()=>{player.runCommand("particle serp:zombie_box ~~~");player.runCommand("particle serp:zombie_box_mol ~~~");player.playSound("mob.cherry_bomb.explode");player.runCommand("damage @e[r=4] 50 none");setDamage(player,item);});};break;}});
world.afterEvents.dataDrivenEntityTrigger.subscribe((event)=>{try{let s=event.entity;let hp=s.getComponent('health');
  switch(event.eventId){
  case("serp:remove"):{if((s.typeId.startsWith("plant:"))&&!s.typeId.includes("cherry_bomb")&&!s.typeId.includes("doom_shroom")){s.runCommand("particle serp:plant_despawn ~~~");s.runCommand("playsound mob.horse.leather @p");}};break;
  case("serp:hypnotized"):{if(s.typeId.startsWith("zombie:")){s.runCommand("execute as @s anchored eyes run particle serp:hypno_spore ~~~");s.addTag("hypnotized");}};break;
  case("serp:death"):{if(s.typeId.startsWith("zombie:")){s.runCommand("playanimation @s animation.pvzzombiebasic.death");}};break;
  case("serp:jumped"):{if(s.typeId.startsWith("zombie:")){let dd=s.getViewDirection();s.applyKnockback(dd.x,dd.z,3.5,0.85);}};break;
  }
}catch{}});
world.afterEvents.projectileHitEntity.subscribe((hit)=>{try{let s=hit.source;let p=hit.projectile;let e=hit.getEntityHit().entity;
if((p.typeId==="serp:pea"||p.typeId==="serp:spore"||p.typeId==="serp:butter")&&!e.typeId.startsWith("plant:")&&!e.hasTag("hypnotized")&&!p.hasTag("on_hit"))
{p.addTag("on_hit");
  if(e.typeId.startsWith("zombie:")&&p.hasTag("frozen")){e.triggerEvent("serp:frozen");e.runCommand("effect @s slowness 1 1 true");}
  if(e.typeId.startsWith("zombie:")&&p.hasTag("fire")){e.triggerEvent("serp:fire");e.runCommand("fill ~~1~ ~~1~ fire replace air");}
  if(e.typeId.startsWith("zombie:")&&p.typeId.includes("butter")){e.triggerEvent("serp:butter");e.runCommand("effect @s slowness 1 1 true");}
p.triggerEvent("serp:remove");}
}catch{}});
world.afterEvents.entityHitEntity.subscribe(({damagingEntity:hitter,hitEntity:victim})=>{try{
  if(hitter.typeId==="minecraft:player"){let item=hitter.getComponent("inventory").container.getItem(hitter.selectedSlotIndex);if(item.typeId.includes("shovel")&&victim.typeId.startsWith("plant:")){victim.triggerEvent("serp:remove");}}
}catch{}});
world.afterEvents.entityHurt.subscribe(({hurtEntity:victim,damageSource:damager})=>{
  if(victim.typeId==="minecraft:player"&&(damager.cause==="entityAttack"||damager.cause==="projectile")){let item=victim.getComponent("inventory").container.getItem(victim.selectedSlotIndex);if((item.typeId==="serp:screen_door"||item.typeId==="serp:newspaper")&&victim.isSneaking){victim.playSound("item.shield.block");const d=victim.getViewDirection();damager.damagingEntity.applyKnockback(d.x,d.z,1.5,0.5);setDamage(victim,item);}}
});
const forms=class gui{
  static start(player){const form=new ActionFormData();form.title("serp.crazy_dave.title");form.body({rawtext:[{text:"§8"},{translate:`serp.pvz.start`},{text:"§r"}]});form.button("gui.confirm");form.show(player).then(result=>{if(result.canceled){this.start(player)}else{}});}
  static menu(player){const form=new ActionFormData();form.title(`serp.plants`);form.body({rawtext:[{text:"§8"},{translate:` ${getScore('sun',player)}`},{text:"§r"}]});for(let u=1;u<=6;u++){let timer="";if(getScore(`timer${u}`,player)>0){timer=Math.round(getScore(`timer${u}`,player)/20)+"  "}for(const plant of plants){if(plant.id==getScore(`plant${u}`,player)){form.button({rawtext:[{text:`${timer}`},{translate:`entity.${plant.name}.name`},{text:`  ${plant.cost}`}]},`textures/items/pvz/${plant.icon}`);}}}form.show(player).then(result=>{if(result.canceled){}else{player.selected=result.selection+1;for(const plant of plants){if(plant.id==getScore(`plant${player.selected}`,player)){for(const block of plant.ob){player.runCommand(`execute as @s at @s if block ~~-0.1~ ${block.n} unless entity @e[family=plants,r=0.75] unless entity @e[family=lawn_mower,r=0.75] run scriptevent serp:setplant`);}}}}});}
  static store(player){const form=new ActionFormData();form.title(`item.serp:phone.name`);form.body({rawtext:[{text:"§8"},{translate:` ${getScore('sun',player)}`},{text:"§r"}]})
  form.button({rawtext:[{translate:`item.serp:sun.name`},{text:`  2`}]},`textures/items/pvz/sun`);
  form.button({rawtext:[{translate:`item.serp:lawn_mower.name`},{text:`  12`}]},`textures/items/pvz/lawn_mower`);
  form.button({rawtext:[{translate:`item.serp:bullet.name`},{text:`  25`}]},`textures/items/pvz/bullet`);
  form.button(`serp.change_seeds`,`textures/items/pvz/empty`);
  form.button(`serp.ask_dave`,`textures/ui/ask_dave`);
  form.show(player).then(result=>{let response=result.selection;
if(result.canceled){}else{switch(response){
  case 0:player.runCommand("scoreboard players add @s[hasitem={item=minecraft:rotten_flesh,quantity=2..}] sun 1");player.runCommand("clear @s[hasitem={item=minecraft:rotten_flesh,quantity=2..}] minecraft:rotten_flesh 0 2");break;
  case 1:player.runCommand("give @s[scores={sun=12..}] serp:lawn_mower");player.runCommand("scoreboard players remove @s[scores={sun=12..}] sun 12");break;
  case 2:player.runCommand("give @s[scores={sun=25..}] serp:bullet 10");player.runCommand("scoreboard players remove @s[scores={sun=25..}] sun 25");break;
  case 3:{const form=new ActionFormData();form.title(`serp.change_seeds`);form.body({rawtext:[{text:"§8"},{translate:"serp.change_seeds_body"},{text:"§r"}]});
  for(let u=1;u<=6;u++){for(const plant of plants){if(plant.id==getScore(`plant${u}`,player)){form.button(`entity.${plant.name}.name`,`textures/items/pvz/${plant.icon}`);}}}
  form.show(player).then(result=>{if(result.canceled){this.store(player)}else{player.selected=result.selection+1;const form=new ActionFormData();form.title(`serp.change_seeds`);form.body(" ");
  for(const plant of plants){for(let u=0;u<=plants.length;u++){if(plant.id==u){form.button(`entity.${plant.name}.name`,`textures/items/pvz/${plant.icon}`);}}}
  form.show(player).then(result=>{if(result.canceled){this.store(player)}else{for(const plant of plants){if(plants.indexOf(plant)==result.selection){if(result.selection==0||(result.selection!=0&&getScore(`plant1`,player)!=plant.id&&getScore(`plant2`,player)!=plant.id&&getScore(`plant3`,player)!=plant.id&&getScore(`plant4`,player)!=plant.id&&getScore(`plant5`,player)!=plant.id&&getScore(`plant6`,player)!=plant.id)){setScore(player,`plant${player.selected}`,plant.id);setScore(player,`sun`,0);}}}}});
  }});};break;
  case 4:{const form=new ActionFormData();form.title("serp.ask_dave");form.body({rawtext:[{text:"§8"},{translate:`serp.crazy_dave.advice${setScoreR(1,5)}`},{text:"§r"}]});form.button("gui.confirm");form.show(player).then(result=>{if(result.canceled){}else{}});};break;
      }}
    });
  }
}
const plants=[{id:0,icon:"empty",name:"plant:empty",ob:[{n:"grass"},{n:"flower_pot"},{n:"waterlily"}],cost:" "},{id:1,icon:"peashooter_seed",name:"plant:peashooter",ob:[{n:"grass"},{n:"flower_pot"},{n:"waterlily"}],cost:4,time:100},{id:2,icon:"sunflower_seed",name:"plant:sunflower",ob:[{n:"grass"},{n:"flower_pot"},{n:"waterlily"}],cost:2,time:100},{id:3,icon:"cherry_bomb_seed",name:"plant:cherry_bomb",ob:[{n:"grass"},{n:"flower_pot"},{n:"waterlily"}],cost:6,time:400},{id:4,icon:"wallnut_seed",name:"plant:wallnut",ob:[{n:"grass"},{n:"flower_pot"},{n:"waterlily"}],cost:2,time:300},{id:5,icon:"potatomine_seed",name:"plant:potatomine",ob:[{n:"grass"},{n:"flower_pot"},{n:"waterlily"}],cost:1,time:300},{id:6,icon:"snow_pea_seed",name:"plant:snow_pea",ob:[{n:"grass"},{n:"flower_pot"},{n:"waterlily"}],cost:7,time:100},{id:7,icon:"chomper_seed",name:"plant:chomper",ob:[{n:"grass"},{n:"flower_pot"},{n:"waterlily"}],cost:6,time:200},{id:8,icon:"repeater_seed",name:"plant:repeater",ob:[{n:"grass"},{n:"flower_pot"},{n:"waterlily"}],cost:8,time:200},{id:9,icon:"puff_shroom_seed",name:"plant:puff_shroom",ob:[{n:"grass"},{n:"flower_pot"},{n:"waterlily"}],cost:0,time:100},{id:10,icon:"sun_shroom_seed",name:"plant:sun_shroom",ob:[{n:"grass"},{n:"flower_pot"},{n:"waterlily"}],cost:1,time:100},{id:11,icon:"fume_shroom_seed",name:"plant:fume_shroom",ob:[{n:"grass"},{n:"flower_pot"},{n:"waterlily"}],cost:3,time:200},{id:12,icon:"grave_buster_seed",name:"plant:grave_buster",ob:[{n:"stone"}],cost:3,time:200},{id:13,icon:"hypno_shroom_seed",name:"plant:hypno_shroom",ob:[{n:"grass"},{n:"flower_pot"},{n:"waterlily"}],cost:3,time:300},{id:14,icon:"scaredy_shroom_seed",name:"plant:scaredy_shroom",ob:[{n:"grass"},{n:"flower_pot"},{n:"waterlily"}],cost:1,time:100},{id:15,icon:"doom_shroom_seed",name:"plant:doom_shroom",ob:[{n:"grass"},{n:"flower_pot"},{n:"waterlily"}],cost:5,time:500},{id:16,icon:"squash_seed",name:"plant:squash",ob:[{n:"grass"},{n:"flower_pot"},{n:"waterlily"}],cost:4,time:300},{id:17,icon:"jalapeno_seed",name:"plant:jalapeno",ob:[{n:"grass"},{n:"flower_pot"},{n:"waterlily"}],cost:5,time:400},{id:18,icon:"spikeweed_seed",name:"plant:spikeweed",ob:[{n:"grass"},{n:"flower_pot"},{n:"waterlily"}],cost:4,time:200},{id:19,icon:"torchwood_seed",name:"plant:torchwood",ob:[{n:"grass"},{n:"flower_pot"},{n:"waterlily"}],cost:7,time:200}];