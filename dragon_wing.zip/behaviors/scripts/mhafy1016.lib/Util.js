// Created by Mhafy1016
// Mhafy.1016#5886

import * as mc from '@minecraft/server';
import string from 'mhafy1016.lib/String';

export const Entity = mc.Entity;
export const Block = mc.Block;
export const BlockVolume = mc.BlockVolume;
export const BiomeTypes = mc.BiomeTypes;
export const BlockPermutation = mc.BlockPermutation;
export const ItemStack = mc.ItemStack;
export const world = mc.world;
export const system = mc.system;

export const PI_180 = Math.PI / 180;

const ALPHABET = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', NUMBERS = '0123456789', SPECIAL = '!@#$%^&*()_-+=<>?';

export const sleep = (delay) => new Promise((resolve) => system.runTimeout(resolve, delay));

world.tmp = {};


Array.prototype.anyEqual = function () {
    return this.filter((item, index) => this.indexOf(item) !== index).length != 0;
}

Array.prototype.allEqual = function () {
    return this.every(val => val === this[0]);
}



Entity.prototype.addItem = function (item) {
    if (this.hasComponent('inventory')) return this.getComponent('inventory').container.addItem(item);
}
Entity.prototype.clearEffects = function () {
    for (let e of this.getEffects()) {
        this.removeEffect(e.typeId);
    }
    return true;
}
Entity.prototype.getScore = function (objective) {
    return world.scoreboard.getObjective(objective).getScore(this);
}
Entity.prototype.setScore = function (objective, score) {
    return world.scoreboard.getObjective(objective).setScore(this, score);
}
Entity.prototype.setItem = function (item, slot) {
    if (!this.hasComponent('inventory')) return;
    let itemStack = item;
    if (typeof item === 'string') {
        if (item === 'minecraft:air' || item === 'air' || item === '') return this.clearItem(slot);
        else if (!item.includes(':')) itemStack = new ItemStack(`minecraft:` + item);
        else itemStack = new ItemStack(item);
    }
    if (itemStack?.typeId === 'minecraft:air') return this.clearItem(slot);
    let s = this.selectedSlot;
    if (!isNaN(slot)) s = slot;
    this.getComponent('inventory').container.setItem(s, itemStack);
}

Entity.prototype.clearItem = function (slot) {
    let s = slot || this.selectedSlot || 0;
    let slot_type = 'slot.hotbar';
    if (s >= 9) {
        slot_type = 'slot.inventory';
        s -= 9;
    }
    this.runCommandAsync(`replaceitem entity @s ${slot_type} ${s} air`);
}

Entity.prototype.getItem = function (slot) {
    let s = slot || this.selectedSlotIndex || 0;
    if (this.hasComponent('inventory')) return this.getComponent('inventory').container.getItem(s);
    return null;
}

Entity.prototype.findItem = function (id) {
    let list = [];
    let con = this.getComponent('inventory').container;
    for (let i = 0; i < con.size; i++) {
        if (con.getItem(i) && con.getItem(i).typeId.includes(id)) {
            list.push({
                item: con.getItem(i),
                slot: i
            });
        }
    }
    return list;
}

Entity.prototype.getEquipment = function (equipmentSlot) {
    if (this.hasComponent("minecraft:equippable"))
        return this.getComponent("minecraft:equippable").getEquipment(equipmentSlot);
    return;
}

Entity.prototype.setEquipment = function (equipmentSlot, itemStack) {
    if (this.hasComponent("minecraft:equippable"))
        return this.getComponent("minecraft:equippable").setEquipment(equipmentSlot, itemStack);
    return;
}

Entity.prototype.getHealth = function() {
    return this.getComponent("minecraft:health") || null;
}

Entity.prototype.isSheared = function () {
    return this.getComponent("is_sheared") || null;
}

Entity.prototype.isIgnited = function () {
    return this.getComponent("minecraft:is_ignited") || null;
}

Entity.prototype.isItem = function () {
    return this.getComponent("item") || null;
}

Entity.prototype.markVariant = function () {
    return this.getComponent('mark_variant') || null;
}
Entity.prototype.variant = function () {
    return this.getComponent('variant') || null;
}

Entity.prototype.skin_id = function () {
    return this.getComponent('skin_id') || null;
}

Entity.prototype.scale = function () {
    return this.getComponent('scale') || null;
}

Entity.prototype.getRide = function () {
    try {
        if (!this.hasComponent('riding') || !this.getComponent('riding')) return null;
        return this.getComponent('riding').entityRidingOn;
    } catch (err) { }
    return null;
}

Entity.prototype.isRiding = function (id = null) {
    let ride = this.getRide();
    if (id) {
        if (ride && ride.isValid()) {
            if (ride.typeId === id || ride.id === id) return ride;
            if (typeof id === 'object') {
                for (let i = 0; i < id.length; i++) {
                    if (ride.typeId === id[i] || ride.id === id[i]) return ride;
                }
            }
        }
        return null
    }
    return ride;
}

Entity.prototype.isRideable = function () {
    return this.getComponent('rideable') || null;
}

Entity.prototype.hasRider = function (list) {
    if (this.isRideable()) for (let e of this.isRideable().getRiders()) {
        if (!e.isValid()) continue;
        if (typeof list === 'object') {
            for (let l of list) {
                if (isNaN(l)) {
                    if (e.typeId.includes(l)) return true;
                } else if (e.id === l) return true;
            }
        } else if (isNaN(list) && e.typeId.includes(list)) return true;
        else if (e.id == list) return true;
    }
    return false;
}

Entity.prototype.getDriver = function () {
    let r;
    try {
        if (!this.isRideable()) return;
        r = this.isRideable().getRiders()[this.isRideable().controllingSeat];
    } catch (err) { }
    return r;
}

Entity.prototype.addRider = function (entity) {
    let ent = entity;
    if (typeof entity === "string") ent = this.dimension.spawnEntity(entity, this.location);
    return new Promise((res, rej) => { (ent && this.isRideable() && this.isRideable().addRider(ent)) ? res({ ride: this, rider: ent }) : rej({ ride: this, error: "Failed" }); });
}
Entity.prototype.isRiding = function (id = null) {
    let ride = this.getRide();
    if (id) {
        if (ride && ride.isValid()) {
            if (ride.typeId === id || ride.id === id) return ride;
        }
        return null
    }
    return ride;
}
Entity.prototype.getFlyingSpeed = function () {
    return this.getComponent('minecraft:flying_speed').value;
}

Entity.prototype.setFlyingSpeed = function (s) {
    this.getComponent('minecraft:flying_speed').value = s;
}

Entity.prototype.color = function () {
    return this.getComponent('color') || null;
}

Entity.prototype.getVelocityVector = function() {
    return Vector.fromV3(this.getVelocity());
}

Entity.prototype.v3 = function () {
    return Vector.fromV3(this.location);
}

Entity.prototype.getBlock = function (x=0, y=0, z=0) {
    return this.dimension.getBlock(this.v3().add(x, y, z)) || {};
}

Entity.prototype.getRadiansRotation = function () {
    return { x: -this.getRotation().x * PI_180, y: -this.getRotation().y * PI_180 };
}

Entity.prototype.distanceTraveled = function () {
    if (!this._location || (this.getVelocity().x == 0 && this.getVelocity().y == 0 && this.getVelocity().z == 0))
        this._location = new Vector(this.location.x, this.location.y, this.location.z);
    return Vector.distance(this._location, this.location);
}

Entity.prototype.traveledDirection = function () {
    if (!this.t_location) this.t_location = new Vector(this.location.x, this.location.y, this.location.z);
    let d = Vector.calculateAngle(this.location, this.t_location);
    this.t_location = new Vector(this.location.x, this.location.y, this.location.z);
    return d;
}

Entity.prototype.properties = function (obj) {
    for (let i in obj) {
        try {
            if (this.getProperty(i) === undefined) continue;
            let n = obj[i];
            if (!isNaN(obj[i]) && (i.startsWith('+') || i.startsWith('-'))) n = this.getProperty(i) + Number(obj[i]);
            this.setProperty(i, n);
        } catch (err) { throw err; }
    }
}

Entity.prototype.addDataAsTag = function (name, value) {
    for (let t of this.getTags()) {
        if (t.startsWith(`${name}=`)) this.removeTag(t);
    }
    this.addTag(`${name}=${value}`);
}

Entity.prototype.getDataFromTag = function (name) {
    for (let t of this.getTags()) {
        if (!t.startsWith(`${name}=`)) continue;
        let val = t.split('=')[1];

        try {
            return JSON.parse(val);
        } catch (err) { };

        return val;
    }
    return;
}

Entity.prototype.getTagFromSample = function (sample) {
    for (let t of this.getTags()) {
        if (t.includes(sample)) return t;
    }
    return;
}

Entity.prototype.removeDataFromTag = function (name) {
    for (let t of this.getTags()) {
        if (t.startsWith(`${name}=`)) this.removeTag(t);
    }
}

Entity.prototype.getAllDataNamesFromTag = function () {
    return this.getTags().filter(a => a.includes('='));
}

Entity.prototype.hasDataFromTag = function (name) {
    for (let t of this.getTags()) {
        if (t.startsWith(`${name}=`)) return true;
    }
    return false;
}

Entity.prototype.clearTag = function () {
    let tag = [];
    for (let t of this.getTags()) {
        tag.push(t);
        this.removeTag(t);
    }
    return tag;
}

Entity.prototype.hasFamily = function (str) {
    let fam = this.getComponent('minecraft:type_family');
    if (fam) return fam.hasTypeFamily(str);
    return false;
}

Entity.prototype.getFamily = function (str) {
    let fam = this.getComponent('minecraft:type_family');
    if (fam) return fam.getTypeFamilies();
    return [];
}






Block.prototype.getState = function (state) {
    return this.permutation.getState(state);
}

Block.prototype.getAllStates = function () {
    let states = {};
    for (let s in this.permutation.getAllStates()) {
        states[s] = this.permutation.getState(s);
    }
    return states;
}

Block.prototype.editState = function (state) {
    let states = {};
    for (let s in this.permutation.getAllStates()) {
        states[s] = this.permutation.getState(s);
    }
    for (let s in state) {
        states[s] = state[s];
    }
    return this.setPermutation(BlockPermutation.resolve(this.typeId, states));
}

Block.prototype.v3 = function () {
    return Vector.fromV3(this.location);
}



ItemStack.prototype.addLore = function (string) {
    return this.setLore(this.getLore().concat(string));
}
ItemStack.prototype.setAmount = function (n, b = true) {
    let total = this.amount;
    if (!isNaN(n)) {
        if (b) total += Number(n);
        else total = Number(n);
    }
    if (total <= 0) return new ItemStack('minecraft:air');
    this.amount = total;
    return this;
}
ItemStack.prototype.isFood = function() {
    return this.getComponent(`minecraft:food`);
}
ItemStack.prototype.durability = function () {
    if (this.hasComponent("minecraft:durability")) {
        return this.getComponent(`minecraft:durability`);
    }
    return;
}
ItemStack.prototype.getNutritionValue = function() {
    if (Number(NUTRITION_VALUES[this.typeId.split(':')[1]])) return NUTRITION_VALUES[this.typeId.split(':')[1]];
    if (this.isFood()) return this.isFood().nutrition;
    return 0;
}


export function Vector(x, y, z) {
    this.x = x;
    this.y = y;
    this.z = z;
}

Vector.fromV3 = function (v) {
    if (typeof v === 'object')
        return new Vector(v.x, v.y, v.z);
    return new Vector(0, 0, 0);
}

Vector.fromAngle = function (angle) {
    let v = new Vector(0, 0, 0);
    v.x = Math.sin(angle.y) * Math.cos(angle.x);
    v.y = Math.sin(angle.x);
    v.z = Math.cos(angle.y) * Math.cos(angle.x);
    return v;
}

Vector.set = function (x, y = 0, z = 0) {
    if (typeof x === 'object') return new Vector(x.x, x.y, x.z);
    else {
        if ([y, z, 0].allEqual()) {
            y = x;
            z = x;
        }
        return new Vector(x, y, z);
    }
    return new Vector(0, 0, 0);
}

Vector.calculate = function (a, b, options = {}) {
    // Calculate the vector between the two points
    let vector = Vector.fromV3(a);
    if (typeof b === 'object') vector = Vector.fromV3(b).sub(a);

    // Calculate the distance between the points
    let distance = Math.sqrt(vector.x * vector.x + vector.y * vector.y + vector.z * vector.z);

    let yaw = Math.atan2(vector.z, vector.x);
    let pitch = Math.atan2(-vector.y, Math.sqrt(vector.x * vector.x + vector.z * vector.z));
    if (options.angle === 'degrees') {
        yaw *= (180 / Math.PI);
        //yaw = ((yaw + 90 + 180) % 360 + 360) % 360 - 180;
        pitch *= (180 / Math.PI);
    }


    return { yaw, pitch, distance };
}

Vector.prototype.clone = function () {
    return new Vector(this.x, this.y, this.z);
}

Vector.prototype.toString = function (raw) {
    if (raw) return `${this.x},${this.y},${this.z}`;
    return `x:${this.x}, y:${this.y}, z:${this.z}`;
}

Vector.prototype.add = function (x, y = 0, z = 0) {
    if (typeof x === 'object') {
        this.x += x.x;
        this.y += x.y;
        this.z += x.z;
    } else {
        if ([y, z, 0].allEqual()) {
            y = x;
            z = x;
        }
        this.x += x;
        this.y += y;
        this.z += z;
    }
    return this;
}
Vector.add = function (v, x, y = 0, z = 0) {
    let t = new Vector(v.x, v.y, v.z);
    if (typeof x === 'object') {
        t.x += x.x;
        t.y += x.y;
        t.z += x.z;
    } else {
        if ([y, z, 0].allEqual()) {
            y = x;
            z = x;
        }
        t.x += x;
        t.y += y;
        t.z += z;
    }
    return t;
}

Vector.prototype.sub = function (x, y = 0, z = 0) {
    if (typeof x === 'object') {
        this.x -= x.x;
        this.y -= x.y;
        this.z -= x.z;
    } else {
        if ([y, z, 0].allEqual()) {
            y = x;
            z = x;
        }
        this.x -= x;
        this.y -= y;
        this.z -= z;
    }
    return this;
}
Vector.sub = function (v, x, y = 0, z = 0) {
    let t = new Vector(v.x, v.y, v.z);
    if (typeof x === 'object') {
        t.x -= x.x;
        t.y -= x.y;
        t.z -= x.z;
    } else {
        if ([y, z, 0].allEqual()) {
            y = x;
            z = x;
        }
        t.x -= x;
        t.y -= y;
        t.z -= z;
    }
    return t;
}

Vector.prototype.divide = function (x, y = 0, z = 0) {
    if (typeof x === 'object') {
        this.x /= x.x;
        this.y /= x.y;
        this.z /= x.z;
    } else {
        if ([y, z, 0].allEqual()) {
            y = x;
            z = x;
        }
        this.x /= x;
        this.y /= y;
        this.z /= z;
    }
    return this;
}
Vector.divide = function (v, x, y = 0, z = 0) {
    let t = new Vector(v.x, v.y, v.z);
    if (typeof x === 'object') {
        t.x /= x.x;
        t.y /= x.y;
        t.z /= x.z;
    } else {
        if ([y, z, 0].allEqual()) {
            y = x;
            z = x;
        }
        t.x /= x;
        t.y /= y;
        t.z /= z;
    }
    return t;
}

Vector.prototype.multiply = function (x, y = 0, z = 0) {
    if (typeof x === 'object') {
        this.x *= x.x;
        this.y *= x.y;
        this.z *= x.z;
    } else {
        if ([y, z, 0].allEqual()) {
            y = x;
            z = x;
        }
        this.x *= x;
        this.y *= y;
        this.z *= z;
    }
    return this;
}
Vector.multiply = function (v, x, y = 0, z = 0) {
    let t = new Vector(v.x, v.y, v.z);
    if (typeof x === 'object') {
        t.x *= x.x;
        t.y *= x.y;
        t.z *= x.z;
    } else {
        if ([y, z, 0].allEqual()) {
            y = x;
            z = x;
        }
        t.x *= x;
        t.y *= y;
        t.z *= z;
    }
    return t;
}

Vector.prototype.magSq = function() {
    const x = this.x;
    const y = this.y;
    const z = this.z;
    return x * x + y * y + z * z;
}

Vector.prototype.floor = function () {
    return new Vector(Math.floor(this.x), Math.floor(this.y), Math.floor(this.z));
}
Vector.prototype.ceil = function () {
    return new Vector(Math.ceil(this.x), Math.ceil(this.y), Math.ceil(this.z));
}

Vector.prototype.getSides = function (filter = []) {
    let sides = [];
    if (!filter.includes('UP')) sides.push(this.clone().add(0, 1, 0)); // up;
    if (!filter.includes('DOWN')) sides.push(this.clone().add(0, -1, 0)); // down;
    if (!filter.includes('NORTH')) sides.push(this.clone().add(0, 0, -1)); // north;
    if (!filter.includes('SOUTH')) sides.push(this.clone().add(0, 0, 1)); // south;
    if (!filter.includes('EAST')) sides.push(this.clone().add(1, 0, 0)); // east;
    if (!filter.includes('WEST')) sides.push(this.clone().add(-1, 0, 0)); // west;
    return sides;
}

Vector.prototype.limit = function(max) {
    const mSq = this.magSq();
    if (mSq > max * max) {
        this.divide(Math.sqrt(mSq)).multiply(max);
    }
    return this;
}

Vector.limit = function (v, max) {
    return Vector.set(v).limit(max);
}

Vector.prototype.normalize = function() {
    const len = this.getMag();
    if (len !== 0) this.multiply(1 / len);
    return this;
}

Vector.prototype.setMag = function (n) {
    return this.normalize().multiply(n);
}

Vector.prototype.getMag = function () {
    return Math.pow(this.x * this.x + this.y * this.y + this.z * this.z, 0.5);
}

Vector.prototype.getDirection = function (target) {
    let v = target.sub(this.clone());
    let mag = v.getMag();
    return v.divide(mag);
}

Vector.prototype.getDistance = function (x, y, z) {
    let dx, dy, dz;
    if (typeof x === 'object') {
        dx = x.x - this.x;
        dy = x.y - this.y;
        dz = x.z - this.z;
    } else {
        if ([y, z, 0].allEqual()) {
            y = x;
            z = x;
        }
        dx = x - this.x;
        dy = y - this.y;
        dz = z - this.z;
    }
    return Math.sqrt(dx * dx + dy * dy + dz * dz);
}

Vector.getDistance = function (v, x, y, z) {
    let t = new Vector(v.x, v.y, v.z);
    let dx, dy, dz;
    if (typeof x === 'object') {
        dx = x.x - t.x;
        dy = x.y - t.y;
        dz = x.z - t.z;
    } else {
        if ([y, z, 0].allEqual()) {
            y = x;
            z = x;
        }
        dx = x - t.x;
        dy = y - t.y;
        dz = z - t.z;
    }
    return Math.sqrt(dx * dx + dy * dy + dz * dz);
}



world.msg = (msg) => world.sendMessage(`${msg}`);

export const OVERWORLD = world.getDimension('overworld');
export const NETHER = world.getDimension('nether');
export const THE_END = world.getDimension('the_end');




export const enchants = [
    'aqua_affinity',
    'bane_of_arthropods',
    'binding',
    'blast_protection',
    'channeling',
    'depth_strider',
    'efficiency',
    'feather_falling',
    'fire_aspect',
    'fire_protection',
    'flame',
    'fortune',
    'frost_walker',
    'impaling',
    'infinity',
    'knockback',
    'looting',
    'loyalty',
    'luck_of_the_sea',
    'lure',
    'mending',
    'multishot',
    'piercing',
    'power',
    'projectile_protection',
    'protection',
    'punch',
    'quick_charge',
    'respiration',
    'reptide',
    'sharpness',
    'silktouch',
    'smite',
    'soul_speed',
    'swift_sneak',
    'thorns',
    'unbreaking',
    'vanishing'
];

export const colors = [
    'black',
    'blue',
    'brown',
    'cyan',
    'gray',
    'green',
    'light_blue',
    'lime',
    'magenta',
    'orange',
    'pink',
    'purple',
    'red',
    'silver',
    'white',
    'yellow'
];

export const NUTRITION_VALUES = {
    'cookie': 2,
    'beef': 3,
    'cooked_beef': 8,
    'porkchop': 3,
    'cooked_porkchop': 8,
    'chicken': 2,
    'cooked_chicken': 6,
    'apple': 4,
    'potato': 1,
    'carrot': 5,
    'cod': 2,
    'cooked_cod': 5,
    'salmon': 2,
    'cooked_salmon': 6,
    'tropical_fish': 2,
    'rabbit': 3,
    'cooked_rabbit': 5,
    'beetroot': 1,
    'beetroot_soup': 6,
    'mushroom_stew': 6,
    'rabbit_stew': 10,
    'melon_slice': 2,
    'pumpkin_pie': 8,
    'golden_apple': 4,
    'enchanted_golden_apple': 4,
    'spider_eye': 2,
    'golden_carrot': 6,
    'rotten_flesh': 4,
    'mutton': 2,
    'cooked_mutton': 6,
    'chorus_fruit': 4,
    'dried_kelp': 1,
    'sweet_berries': 1,
};



export function generateId(length, filter = []) {
    let COMBI = '';
    if (!filter.includes('ALPHABET')) {
        if (!filter.includes('UPPER_ALPHABET')) COMBI += ALPHABET;
        if (!filter.includes('LOWER_ALPHABET')) COMBI += ALPHABET.toLowerCase();
    }
    if (!filter.includes('NUMBERS')) COMBI += NUMBERS;
    if (!filter.includes('SPECIAL')) COMBI += SPECIAL;
    //const COMBI = ALPHABET + ALPHABET.toLowerCase() + NUMBERS + SPECIAL;
    return ' '.repeat(length).replace(/ /g, _ => COMBI.charAt(Math.floor(Math.random() * COMBI.length)));
}

export function generateUUID() {
    const COMBI = ALPHABET + ALPHABET.toLowerCase() + NUMBERS;
    return "########-####-####-####-############".replace(/#/g, _ => COMBI.charAt(Math.floor(Math.random() * COMBI.length)));
}

export function removeEntity(id) {
    let e = world.getEntity(id);
    if (e != undefined && e.isValid()) {
        e.remove();
        return true;
    }
    return false;
}

export function clamp(n, min, max) {
    return Math.min(Math.max(n, min), max);
}

export function partAngle(a, n) {
    let p = (360 / n);
    let angle = Math.round(((a + 360) % 360) / p) * p;
    return angle >= 180 ? angle - 360 : angle;
}

export function hasFamilyAny(e, list) {
    if (!(e && e.isValid())) return false;
    let fam = e.getComponent('minecraft:type_family');
    if (fam) for (let f of fam.getTypeFamilies()) {
        if (list.includes(f)) return true;
    }
    return false;
}

export function hasFamilyAll(e, list) {
    if (!(e && e.isValid())) return false;
    let fam = e.getComponent('minecraft:type_family');
    if (fam) for (let f of fam.getTypeFamilies()) {
        if (list.includes(f)) list.splice(list.indexOf(f), 1);
    }
    return list.length == 0;
}

export function constrain(n, low, high) {
    return Math.max(Math.min(n, high), low);
}

export function map(n, start1, stop1, start2, stop2, within) {
    const newval = (n - start1) / (stop1 - start1) * (stop2 - start2) + start2;
    if (!within) return newval;
    if (start2 < stop2) return constrain(newval, start2, stop2);
    return constrain(newval, stop2, start2);
}

export function angleDifference(a, b) {
    let diff = ((b - a + 180) % 360) - 180;
    return (diff < -180) ? (diff + 360) : diff;
}


export default {
    PI_180,

    sleep,
    world, system, Entity,
    Block,
    BlockVolume,
    BlockPermutation,
    BiomeTypes,
    Vector, ItemStack,
    enchants, colors,

    OVERWORLD, NETHER, THE_END,
    generateId, generateUUID,
    removeEntity,
    clamp, partAngle,

    hasFamilyAny, hasFamilyAll,
    constrain, map, angleDifference
};