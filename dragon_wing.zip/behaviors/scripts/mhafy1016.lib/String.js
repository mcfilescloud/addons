// Created by Mhafy1016
// Mhafy.1016#5886

export const string = String;

const color = {
    dark_red: '\u00A74',
    red: '\u00A7c',
    gold: '\u00A76',
    yellow: '\u00A7e',
    dark_green: '\u00A72',
    green: '\u00A7a',
    aqua: '\u00A7b',
    dark_aqua: '\u00A73',
    dark_blue: '\u00A71',
    blue: '\u00A79',
    light_purple: '\u00A7d',
    dark_purple: '\u00A75',
    white: '\u00A7f',
    gray: '\u00A77',
    dark_gray: '\u00A78',
    black: '\u00A70',
    obfuscated: '\u00A7k',
    bold: '\u00A7l',
    strikethrough: '\u00A7m',
    underline: '\u00A7n',
    italic: '\u00A7o',
    reset: '\u00A7r'
};

string.color = color;

string.prototype.dark_red = function () { return `${color.dark_red + this + color.reset}`; }
string.prototype.red = function () { return `${color.red + this + color.reset}`; }
string.prototype.gold = function () { return `${color.gold + this + color.reset}`; }
string.prototype.yellow = function () { return `${color.yellow + this + color.reset}`; }
string.prototype.dark_green = function () { return `${color.dark_green + this + color.reset}`; }
string.prototype.green = function () { return `${color.green + this + color.reset}`; }
string.prototype.aqua = function () { return `${color.aqua + this + color.reset}`; }
string.prototype.dark_aqua = function () { return `${color.dark_aqua + this + color.reset}`; }
string.prototype.dark_blue = function () { return `${color.dark_blue + this + color.reset}`; }
string.prototype.blue = function () { return `${color.blue + this + color.reset}`; }
string.prototype.light_purple = function () { return `${color.light_purple + this + color.reset}`; }
string.prototype.dark_purple = function () { return `${color.dark_purple + this + color.reset}`; }
string.prototype.white = function () { return `${color.white + this + color.reset}`; }
string.prototype.gray = function () { return `${color.gray + this + color.reset}`; }
string.prototype.dark_gray = function () { return `${color.dark_gray + this + color.reset}`; }
string.prototype.black = function () { return `${color.black + this + color.reset}`; }

string.prototype.obfuscated = function () { return `${color.obfuscated + this + color.reset}`; }
string.prototype.bold = function () { return `${color.bold + this + color.reset}`; }
string.prototype.strikethrough = function () { return `${color.strikethrough + this + color.reset}`; }
string.prototype.underline = function () { return `${color.underline + this + color.reset}`; }
string.prototype.italic = function () { return `${color.italic + this + color.reset}`; }
string.prototype.reset = function () { return `${color.reset + this + color.reset}`; }

string.prototype.replaceAt = function () { return this.substring(0, index) + replacement + this.substring(index + replacement.length); }
string.prototype.capFirstLetter = function () { return (this.charAt(0).toUpperCase() + this.slice(1)); }
string.prototype.parse = function () { return JSON.parse(this); }

string.prototype.isOnList = function (list) {
    for (let item of list) {
        if (this.includes(item)) return true;
    }
    return false;
}

export default string;