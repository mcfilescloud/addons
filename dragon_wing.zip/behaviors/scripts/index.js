import { world, system, Vector, ItemStack, map } from 'mhafy1016.lib/Util';

const MAX_SPEED = 0.8;
const MAX_FORCE = 0.15;
const HOVER_SPEED = 1.2;
const showParticles = false;

function load() {
    system.runInterval(tick, 0);
}

function tick() {
    for (let player of world.getPlayers()) {
        try {
            if (player.vel == undefined) player.vel = player.vel = player.getVelocityVector();
            if (player.kamikazee == undefined) player.kamikazee = 0;
            if (player.bonusSpeed == undefined) player.bonusSpeed = 0;
            if (player.lastPlayed == undefined) player.lastPlayed = 0;

            if (player.hasTag("player.isStarving")) {
                if (player.isStarving_tick > 0) player.isStarving_tick -= 1;
                else if (player.getHealth()?.currentValue > 1) {
                    player.removeTag(`player.isStarving`);
                    delete player.isStarving_tick;
                }
                //player.onScreenDisplay.setActionBar("Starving");
            }

            player.findItem("ewings:").forEach(r => { // Resetting damage
                if (r.item.durability().damage != 0) {
                    r.item.durability().damage = 0;
                    player.setItem(r.item, r.slot);
                }
            });

            let chest = player.getEquipment('Chest');
            if (chest?.typeId?.startsWith('ewings:')) {
                if (player.hasTag('player.isFlying') || player.hasTag('player.isHovering'))
                    player.addEffect("slow_falling", 20, { showParticles });
                else player.addEffect("slow_falling", 1, { showParticles });

                if (player.hasTag('player.isFlying')) isFlying(player);
                else if (player.hasTag('player.isHovering')) isHovering(player);
                else {
                    if (chest.durability().damage != 0) player.setEquipment("Chest", new ItemStack(chest.typeId));
                    if (player.isJumping) {
                        if (!player.hasJumped && system.currentTick - player.jumpTick < 5) {
                            player.addTag("player." + (player.isSneaking ? 'isHovering' : 'isFlying'));
                            delete player.jumpTick;
                            delete player.hasJumped;
                        }
                        player.jumpTick = system.currentTick;
                        player.hasJumped = true;
                    } else player.hasJumped = false;
                }
            } else reset(player);

            /**/
        } catch (err) {
            player.scriptRetry = (player.scriptRetry || 0) + 1
            reset(player);
            throw `${player.nameTag} has dealt an error\n ${3 - player.scriptRetry} tries left\n${err}`;
        }
    }  
}

function isFlying(player) {
    let wings = player.getEquipment('Chest'), amplifier = 0;
    if (player.hasTag("player.isStarving")) wings.durability().damage = 11;
    else wings.durability().damage = 1;
    player.setEquipment("Chest", wings);

    if ((system.currentTick - player.lastPlayed) >= 190) {
        player.playSound(`wings.wind_effect`, { volume: 0.2 });
        player.lastPlayed = system.currentTick;
    }

    let speed = MAX_SPEED + player.bonusSpeed;
    if (player.isSprinting) speed *= 1.2;

    const target = Vector.set(player.getViewDirection()).setMag(speed);
    const vel = player.vel.limit(speed);
    if (player.hasTag("player.isStarving")) target.y = Math.min(target.y, -0.1);
    const steering = Vector.sub(target, vel).limit(MAX_FORCE);
    const mag = Math.sqrt((vel.x ** 2) + (vel.z ** 2));
    let pitch = vel.y * 0.75;
    if (player.getRotation().x > 45) player.kamikazee += map(player.getRotation().x - 45, 0, 45, 0, 0.01);
    else player.kamikazee *= 0.95;

    if (vel.y > 0) amplifier = ~~(vel.y * (8 + (player.isSprinting ? 10 : 0))) + 1;
    else pitch = vel.y * 0.4;
    if (amplifier > 0) player.addEffect(`hunger`, 1, { amplifier, showParticles });

    player.applyKnockback(vel.x, vel.z, mag, pitch - player.kamikazee);
    if (player.isOnGround || player.getBlock(0, 0.5, 0)?.typeId === "minecraft:water") return reset(player);
    if (player.isSneaking) return reset(player).addTag(`player.isHovering`);
    player.vel.add(steering);

    if (player.getRotation().x < -2) {
        playFlapSound(player, wings);
    } else delete player.lastFlapSound;
}

function isHovering(player) {
    let wings = player.getEquipment('Chest');
    if (player.hasTag("player.isStarving")) wings.durability().damage = 12;
    else wings.durability().damage = 2;
    player.setEquipment("Chest", wings);

    const vel = player.getVelocityVector();
    let yy = player.hoverY || 0, multipler = 1, amplifier = 1;

    if (player.isJumping) {
        if (!player.hasJumped && system.currentTick - player.jumpTick < 5) return reset(player).addTag('player.isFlying');
        delete player.hasSneaked;
        player.jumpTick = system.currentTick;
        player.hasJumped = true;
        delete player.hasSneaked;
        delete player.yy;

        if (!player.hasTag("player.isStarving")) {
            yy = Math.min(yy + 0.02, 0.2);
            amplifier = 4;
        }
    }
    else if (player.isSneaking) {
        if (!player.hasSneaked && system.currentTick - player.sneakTick < 10) return reset(player).removeEffect("levitation");
        player.sneakTick = system.currentTick;
        player.hasSneaked = true;
        delete player.hasJumped;
        delete player.yy;

        yy = Math.max(yy - 0.01, -0.1);
    }
    else if (!player.isJumping && !player.isSneaking) {
        delete player.hasJumped;
        delete player.hasSneaked;
        yy *= 0.8;
        player.addEffect("levitation", 20, { showParticles });
    }
    if (player.hasTag("player.isStarving")) yy = Math.max(yy - 0.01, -0.1);

    if (!player.isSneaking) {
        playFlapSound(player, wings);
    } else delete player.lastFlapSound;

    if (player.isSprinting) {
        multipler *= 1.3;
        amplifier *= 2;
    }
    if (amplifier > 0) player.addEffect(`hunger`, 1, { amplifier, showParticles });
    
    let mag = Math.min(Math.sqrt(vel.x * vel.x + vel.z * vel.z), 0.2158 * multipler);
    if (mag < 0.01) mag = 0;
    const y_speed = mag * HOVER_SPEED * multipler;
    player.applyKnockback(vel.x, vel.z, y_speed, yy);
    player.hoverY = yy;
    if ((player.isOnGround && player.getVelocity().y == 0) || player.getBlock(0, 0.5, 0)?.isLiquid) return reset(player); 
}

function playFlapSound(player, wings) {
    let interval = 5;
    let delay = 5;
    let location = player.v3().add(0, 1, 0), volume = 0.3, pitch = 1;
    let sound = "wings.flap";
    if (wings.typeId.includes("feather")) {
        interval = 8;
        delay = 12;
    }
    else if (wings.typeId.includes("dragonfly")) {
        sound = "dragonfly.flap";
        volume = 0.5;
        interval = 1;
        delay = 0;
    }
    else if (wings.typeId.includes("fairy")) {
        sound = "insect_wings.flap";
        volume = 0.5;
        interval = 5;
        delay = 0;
    }

    if (!player.lastFlapSound) player.lastFlapSound = system.currentTick;
    if ((system.currentTick - player.lastFlapSound) >= interval) {
        player.dimension.playSound(sound, location, { volume, pitch });
        player.lastFlapSound = system.currentTick + delay;
    }
}

function reset(player) {
    if (player.hasTag("player.isFlying") || player.hasTag("player.isHovering")) player.addEffect("slow_falling", 1, { amplifier: 10 });
    player.runCommandAsync(`stopsound @s`);
    player.removeTag(`player.isFlying`);
    player.removeTag(`player.isHovering`);
    player.vel = new Vector(0, 0, 0);
    player.kamikazee = 0;
    delete player.hoverY;
    delete player.jumpTick;
    delete player.hasJumped;
    delete player.sneakTick;
    delete player.hasSneaked;
    delete player.hoverY;
    delete player.lastFlapSound;
    player.removeEffect("levitation");

    return player;
}

world.afterEvents.itemCompleteUse.subscribe(e => {
    if (e.itemStack.getNutritionValue() < 0) return;
    e.source.removeTag(`player.isStarving`);
    if (e.source.getHealth()?.currentValue <= 1) e.source.getHealth().setCurrentValue(2);
});

world.afterEvents.playerSpawn.subscribe(e => {
    if (e.player.hasTag('player.isStarving')) e.player.isStarving_tick = 80;
});

world.afterEvents.entityHurt.subscribe(e => {
    if (e.damageSource.cause !== "starve") return;
    e.hurtEntity.addTag("player.isStarving");
    e.hurtEntity.isStarving_tick = 80;
}, { entityTypes: ["minecraft:player"] });

world.afterEvents.entityDie.subscribe(e => {
    try {
        let n = Math.random(), explosion = 0, arrow = 0, trident = 0, looting = 1;
        let id = `${e.deadEntity.typeId}`, loot = '';
        let attacker = '', cause = '';

        if (e.damageSource.damagingEntity) attacker = e.damageSource.damagingEntity;
        if (e.damageSource.cause) cause = e.damageSource.cause;

        if (attacker.typeId == 'minecraft:creeper' && cause == 'entityExplosion') explosion = 1;
        else if (attacker.typeId == 'minecraft:skeleton' && cause == 'projectile') arrow = 1;
        else if (attacker.typeId == 'minecraft:zombie' && cause == 'projectile') trident = 1;
        let item = attacker?.getEquipment("Mainhand");
        if (item) {
            let enchant = item.getComponent("minecraft:enchantable");
            if (enchant) looting += (enchant.getEnchantment("looting")?.level || 0);
        }

        if (id.includes('bat') && n < (0.1 * looting) + (0.15 * explosion) + (0.18 * arrow) + (0.25 * trident)) loot = 'bat';
        else if (id.includes('vex') && n < (0.02 * looting) + (0.07 * explosion) + (0.10 * arrow) + (0.20 * trident)) loot = 'vex';
        else if (id.includes('bee') && n < (0.05 * looting) + (0.10 * explosion) + (0.13 * arrow) + (0.20 * trident)) loot = 'bee';
        else if (id.includes('chicken') && n < (0.02 * looting) + (0.07 * explosion) + (0.10 * arrow) + (0.20 * trident)) loot = 'chicken';
        else if (n < (0.05 * looting) + (0.10 * explosion) + (0.13 * arrow) + (0.20 * trident))
            e.deadEntity.runCommandAsync(`summon ewings:demon_wings ~~~`);
        if (loot !== '') e.deadEntity.runCommandAsync(`loot spawn ~~~ loot "wings/${loot}"`);
    } catch (err) { }
});

system.run(load);