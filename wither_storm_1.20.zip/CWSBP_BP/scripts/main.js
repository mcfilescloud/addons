import * as server from "@minecraft/server";

server.world.afterEvents.worldInitialize.subscribe(() => {
  server.world.getDimension(`overworld`).runCommandAsync(`structure load house 5 62 5`).then(() => {
    server.world.sendMessage(`Successfully generated structure.`)
  })
})