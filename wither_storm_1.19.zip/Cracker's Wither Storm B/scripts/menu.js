import { world } from "mojang-minecraft"
import { ModalFormData } from "mojang-minecraft-ui"

world.events.blockPlace.subscribe(eventData => blockPlace(eventData));
function blockPlace(eventData) {
    const  placeBlock = eventData.block;
    const locX = placeBlock.location.x;
    const locY = placeBlock.location.y;
    const locZ = placeBlock.location.z;    
    const blocks = ["minecraft:command_block"]
        if (blocks.includes(placeBlock.type.id)) {
       eventData.player.runCommand(`summon mc:testfor_block ${locX} ${locY} ${locZ}`);
       } else {}
     }

 
world.events.blockBreak.subscribe(eventData => blockBreak(eventData));
function blockBreak(eventData) {
    const  brokenBlock = eventData.block;
    const permutation = eventData.brokenBlockPermutation;
    const locX = brokenBlock.location.x;
    const locY = brokenBlock.location.y;
    const locZ = brokenBlock.location.z;    
    const blocks = ["minecraft:command_block"]
        if (blocks.includes(permutation.type.id)) {
       eventData.player.runCommand(`function command`);
       } else {}
     }



     
world.events.beforeChat.subscribe((FlizerX) => { 
	if (FlizerX.message.startsWith("phase +1")) {
		FlizerX.cancel = true;
		FlizerX.sender.runCommand("function test_grow");
		FlizerX.sender.runCommand("give @p");
		FlizerX.sender.runCommand("give @p");
		}});

world.events.beforeChat.subscribe((FlizerX) => { 
	if (FlizerX.message.startsWith("phase -1")) {
		FlizerX.cancel = true;
		FlizerX.sender.runCommand("function test_grow2");
		FlizerX.sender.runCommand("give @p");
		FlizerX.sender.runCommand("give @p");
		}});

world.events.beforeChat.subscribe((FlizerX) => { 
	if (FlizerX.message.startsWith("fly +1")) {
		FlizerX.cancel = true;
		FlizerX.sender.runCommand("function me2");
		FlizerX.sender.runCommand("function me3");
		FlizerX.sender.runCommand("scoreboard players add @e[type=mc:ws_boss] flyx 1");
		FlizerX.sender.runCommand("execute @e[type=mc:ws_boss] ~~~ execute @e[scores={flyx=..3}] ~~~ tp @s ~~16~");


		}});
	
world.events.beforeChat.subscribe((FlizerX) => { 
	if (FlizerX.message.startsWith("r")) {
		FlizerX.cancel = true;
		FlizerX.sender.runCommand("scoreboard players reset @e flyx");
		FlizerX.sender.runCommand("give @p");
		FlizerX.sender.runCommand("give @p");
		}});

world.events.beforeChat.subscribe((FlizerX) => { 
	if (FlizerX.message.startsWith("fly -1")) {
		FlizerX.cancel = true;
		FlizerX.sender.runCommand("function me1");
		FlizerX.sender.runCommand("function me3");
		FlizerX.sender.runCommand("scoreboard players add @e[type=mc:ws_boss] flyx -1");
		FlizerX.sender.runCommand("execute @e[type=mc:ws_boss] ~~~ tp @s ~~2~");

		}});

world.events.beforeItemUse.subscribe((eventData) => {
    const player = eventData.source 
    if(eventData.item.id == "mc:settings") {
    	Menu(player);
    }});
 
    function Menu(player) {
    const modal = new ModalFormData()
      .title("§5Cracker's Wither Storm Settings")
      .toggle("Blocks",true)
      .toggle("Wither Storm Follows Players",true)

      .toggle("Clouds",true)
      .toggle("§l§5Tractor Beam Pulls Mobs",true)           
        modal.show(player).then(result => {
            if (result.formValues[0] == false) {
                player.runCommand("function blocks_off")
               }
           if (result.formValues[0] == true) {
            	player.runCommand("function blocks_on")
            }
            if (result.formValues[1] == false) {
                player.runCommand("function Wither_Storm_Follows_Players_off")
               }
           if (result.formValues[1] == true) {
            	player.runCommand("function Wither_Storm_Follows_Players_on")
}
            if (result.formValues[2] == false) {
                player.runCommand("function fast_tracking_off")
               }
           if (result.formValues[2] == true) {
            	player.runCommand("function fast_tracking_on")
}
            if (result.formValues[3] == false) {
                player.runCommand("function clouds_off")
               }
           if (result.formValues[3] == true) {
            	player.runCommand("function clouds_on")       
}
            if (result.formValues[4] == false) {
                player.runCommand("function beam_off")
               }
           if (result.formValues[4] == true) {
            	player.runCommand("function beam_on")    
         }})}