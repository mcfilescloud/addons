import {world, system, BlockTypes, BlockPermutation, EntityEquippableComponent, EquipmentSlot, ItemStack} from '@minecraft/server';
    
class PortalGunBook_Main {
	
	run(){	
		
		world.beforeEvents.worldInitialize.subscribe((event)=>{
			event.itemComponentRegistry.registerCustomComponent("pg:book", {
				onUse: event => {
					const {source : player, itemStack : item} = event
					const bookID = item.typeId
					const equippableComponent = player.getComponent(EntityEquippableComponent.componentId)
					let itemBook = undefined
					switch(bookID){
						case "pg:pg_book":
							itemBook = new ItemStack("pg:pg_book2")
							break
						case "pg:pg_book2":
							itemBook = new ItemStack("pg:pg_book3")
							break
						case "pg:pg_book3":
							itemBook = new ItemStack("pg:pg_book")
							break
					}
					equippableComponent.setEquipment(EquipmentSlot.Mainhand, itemBook)
					player.playSound("book.flip")
				}				
			})
		})
	}
}	

const pgBook = new PortalGunBook_Main()
export default pgBook