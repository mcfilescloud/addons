import {world, system, BlockTypes} from '@minecraft/server';
    
export class Props_Main{
	
	static run(){	
		//////////////////////////////////
		//ENVIRONMENTS
		//////////////////////////////////
		system.runInterval(()=>{
			let allPlayers = world.getPlayers();
			for(let player of allPlayers){
				for(let y=0; y<=2; y++){
					for(let x=-1; x<=1; x++){
						for(let z=-1; z<=1; z++){
							let setLocation = {x:player.location.x+x,y:player.location.y+y,z:player.location.z+z};
							let block = player.dimension.getBlock(setLocation).typeId;
							if(block.includes("barrier_block_inactive_side")){
								player.dimension.fillBlocks(setLocation,setLocation,BlockTypes.get("pg:barrier_block_active_side"));
							}else if(block.includes("barrier_block_inactive")){
								player.dimension.fillBlocks(setLocation,setLocation,BlockTypes.get("pg:barrier_block_active"));
							}
						}
					}
				}					
			}			
		},1);
	}	
}