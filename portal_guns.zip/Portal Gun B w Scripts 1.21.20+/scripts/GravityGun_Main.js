import {world, system, BlockTypes, BlockPermutation, EntityEquippableComponent, EquipmentSlot} from '@minecraft/server';
    
class GravityGun_Main {
	
	run(){	
		let levitatingBlocks = []
		let levitatingEntities = []
		
		world.beforeEvents.worldInitialize.subscribe((event)=>{
			event.itemComponentRegistry.registerCustomComponent("pg:gravity_gun", {
				onUse: event => {
					const {source : player, itemStack : item} = event
					const blockFromViewDirection = player.getBlockFromViewDirection({includePassableBlocks:false, includeLiquidBlocks:false, maxDistance:8})
					const entityFromViewDirection = player.getEntitiesFromViewDirection({excludeTypes:["minecraft:player"], excludeFamilies:["pg"], maxDistance:8})
					const block = blockFromViewDirection?.block
					const entitiesRaycastHit = entityFromViewDirection
					if(entitiesRaycastHit.length){
						const entity = entitiesRaycastHit[0].entity
						const entityLevitatingObj = {owner: player, entity}
						const newList = []				
						for(const entryObj of levitatingEntities){				
							if(entryObj.entity.id != entity.id){
								newList.push(entryObj)						
								continue
							}
							const playerViewDirection = player.getViewDirection()
							entryObj.entity.applyKnockback(playerViewDirection.x, playerViewDirection.z, 8, playerViewDirection.y * 3)
							levitatingEntities = newList
							return
						}
						levitatingEntities.push(entityLevitatingObj)
						levitatingEntities = levitatingEntities.filter((item, index, self) => {
						return self.findIndex(obj => obj.owner.id === item.owner.id) === index;
						});
						return
					}
					if(block){
						//block.setPermutation(BlockPermutation.resolve("minecraft:air"))
					}			
				}				
			})
		})

		system.runTimeout(()=>{
			system.runInterval(()=>{
				levitatingEntities.forEach((entryObj)=>{
					const {owner : player, entity} = entryObj
					if(!entity.isValid() || !player.isValid()){
						levitatingEntities = levitatingEntities.map((levitatingEntryObj)=>{
							if(entity.isValid() && player.isValid()){
								return levitatingEntryObj
							}
							return null
						}).filter((entry) => entry !== null);
						return
					}			
					const playerMainHandItem = player.getComponent(EntityEquippableComponent.componentId).getEquipment(EquipmentSlot.Mainhand)
					if(!playerMainHandItem || !playerMainHandItem.typeId.includes("gravity_gun")){
						levitatingEntities = levitatingEntities.map((levitatingEntryObj)=>{
							if(entity.id != levitatingEntryObj.entity.id){
								return levitatingEntryObj
							}
							return null
						}).filter((entry) => entry !== null);
						return
					}			
					const playerDimension = player.dimension
					const playerLocation = player.location
					const playerViewDirection = player.getViewDirection()
					playerLocation.y += 1 + playerViewDirection.y * 0.5
					playerLocation.x += playerViewDirection.x * 1.5
					playerLocation.z += playerViewDirection.z * 1.5
					entity.teleport(playerLocation, {dimension:playerDimension})
				})
			})
		},60)
	}
}	

const gravityGunMain = new GravityGun_Main()
export default gravityGunMain