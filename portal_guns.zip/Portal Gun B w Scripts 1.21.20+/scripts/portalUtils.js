import { world, Entity, MinecraftDimensionTypes, EntityTameableComponent, system } from "@minecraft/server";

class utils{

	/**
	 * @param {Array} portalList
	 * @param {number} id
	 * @returns {Object}
	 */
	getPortalEntry(id, portalList) {
		for(const portalObj of portalList){
			if(portalObj.id == id){
				return portalObj
			}
		}
		return {id: id, bluePortal: undefined, orangePortal: undefined }
	}

	/**
	 * @param {Object} entryObj
	 * @param {Array} portalList
	 * @returns {Array}
	 */
	setPortalEntry(entryObj, portalList){
		const newPortalList = portalList.map((portalObject)=>{
			if(entryObj.id != portalObject.id) return portalObject
			return null
		}).filter((entry) => entry !== null);
		newPortalList.push(entryObj)
		return newPortalList
	}

	/**
	 * @param {Array} portalList
	 * @returns {Array}
	 */
	validatePortals(portalList){
		return portalList.map((portalObj) => {
			const updatedPortalObj = { ...portalObj };
			if (!updatedPortalObj.bluePortal?.isValid()) {
				updatedPortalObj.bluePortal = undefined;
			}
			if (!updatedPortalObj.orangePortal?.isValid()) {
				updatedPortalObj.orangePortal = undefined;
			}
			if(updatedPortalObj.orangePortal == undefined && updatedPortalObj.bluePortal == undefined){
				return null
			}
			return updatedPortalObj;
		}).filter((entry) => entry !== null);
	}

	/**
	 * @param {Array} portalList
	 * @param {number} id
	 * @param {Entity} portalEntity
	 * @returns {Array}
	 */
	removePortal(id, portalEntity, portalList){
		const portalID = portalEntity.id
		return portalList.map((portalObject)=>{	
			const newPortalObject = {...portalObject}	
			if(newPortalObject.id == id){
				if(portalID == newPortalObject.bluePortal?.id) newPortalObject.bluePortal = undefined
				if(portalID == newPortalObject.orangePortal?.id) newPortalObject.orangePortal = undefined
				if(newPortalObject.orangePortal == undefined && newPortalObject.bluePortal == undefined) return null
			}
			return newPortalObject
		}).filter((entry) => entry !== null)
	}

	/**
	 * @param {Object} portalObj
	 * @returns {Entity}
	 */
	getPartnerPortal(portalEntity, portalObj){
		const bluePortal = portalObj.bluePortal
		const orangePortal = portalObj.orangePortal
		const portalID = portalEntity.id
		if(bluePortal?.id == portalID) return orangePortal
		if(orangePortal?.id == portalID) return bluePortal
		return null
	}

	/**
	 * @param {Object} portalObj
	 * @returns {Entity}
	 */
	initializePortals(portalList){
		const dimensionList = [MinecraftDimensionTypes.overworld, MinecraftDimensionTypes.nether, MinecraftDimensionTypes.theEnd]
		for(const dimensionType of dimensionList){
			const dimension = world.getDimension(dimensionType)
			const portalEntityList = dimension.getEntities({families:["portal", "pg"]})
			for(const portalEntity of portalEntityList){
				const entityID = portalEntity.typeId
				const owner = portalEntity.getComponent(EntityTameableComponent.componentId).tamedToPlayer
				const portalEntryObject = this.getPortalEntry(owner.id, portalList)
				if (entityID.includes("_b")) {
					portalEntryObject.bluePortal = portalEntity;
				} else if (entityID.includes("_o")) {
					portalEntryObject.orangePortal = portalEntity;
				}
				portalList = this.setPortalEntry(portalEntryObject, portalList)
			}
		}
		return portalList
	}
}

const pgUtils = new utils()
export default pgUtils