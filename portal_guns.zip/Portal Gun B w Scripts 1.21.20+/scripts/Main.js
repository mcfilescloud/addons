import { Direction, Entity, EntityDamageCause, EntityEquippableComponent, EntityInitializationCause, EntityTameableComponent, EquipmentSlot, ItemStack, MinecraftDimensionTypes, System, system, world } from "@minecraft/server";
import pgUtils from './portalUtils.js'
import gravityGunMain from './GravityGun_Main.js'
import portalGunBookMain from './portalGunBook_Main.js'

portalGunBookMain.run()
gravityGunMain.run()

let portalList = []

world.beforeEvents.worldInitialize.subscribe((event)=>{
	event.itemComponentRegistry.registerCustomComponent("pg:blue_shoot", {
		onUse: event => {
			const { source : player, itemStack : item} = event
			const playerDimension = player.dimension
			const playerLocation = player.location
			let portalGunOrangeItem = new ItemStack("pg:portal_gun_orange")
			if(item.typeId.includes("glados")){
				portalGunOrangeItem = new ItemStack("pg:portal_gun_orange_glados_beta")
			}else if(item.typeId.includes("rnm")){
				portalGunOrangeItem = new ItemStack("pg:portal_gun_rnm2")
			}
			player.getComponent(EntityEquippableComponent.componentId).setEquipment(EquipmentSlot.Mainhand, portalGunOrangeItem)
			playerDimension.playSound("gun.shoot", playerLocation)
		}
	})
	event.itemComponentRegistry.registerCustomComponent("pg:orange_shoot", {
		onUse: event => {
			const { source : player, itemStack : item} = event
			const playerDimension = player.dimension
			const playerLocation = player.location
			let portalGunBlueItem = new ItemStack("pg:portal_gun_blue")
			if(item.typeId.includes("glados")){
				portalGunBlueItem = new ItemStack("pg:portal_gun_blue_glados_beta")
			}else if(item.typeId.includes("rnm")){
				portalGunBlueItem = new ItemStack("pg:portal_gun_rnm1")
			}
			player.getComponent(EntityEquippableComponent.componentId).setEquipment(EquipmentSlot.Mainhand, portalGunBlueItem)
			playerDimension.playSound("gun.shoot", playerLocation)
		}
	})
})

world.afterEvents.projectileHitBlock.subscribe((event)=>{
	const {projectile : entity, hitVector} = event
	const entityID = entity.typeId
	const pgBulletRegex = '\pg:|bullet\g'
	if(entityID.match(pgBulletRegex)){
		const owner = entity.getComponent(EntityTameableComponent.componentId)?.tamedToPlayer
		if(owner){			
			const blockHit = event.getBlockHit().block
			const hitBlockFace = event.getBlockHit().face
			const blockLocation = blockHit.location
			const hitVectorX = Math.round(hitVector.x)
			const hitVectorZ = Math.round(hitVector.z)
			const playerDimension = owner.dimension
			const bulletLocation = entity.location
			if(hitBlockFace == Direction.Up){
				bulletLocation.y = blockLocation.y + 1
			}else if(hitBlockFace == Direction.Down){
				bulletLocation.y = blockLocation.y - 2
			}
			const portalName = `${owner.name}'s Portal`
			let rotation = 0
			let spawnedPortalEntity
			system.runTimeout(()=>{
				if(hitVectorX == 1 && hitVectorZ == 0){
					rotation = 90
				}else if(hitVectorX == 0 && hitVectorZ == -1){
					rotation = 0
				}else if(hitVectorX == -1 && hitVectorZ == 0){
					rotation = -90
				}else if(hitVectorX == 0 && hitVectorZ == 1){
					rotation = 180
				}
				if(!entityID.includes("glados") && !entityID.includes("rnm")){
					if(entityID.includes("bullet_b")){
						const oldBluePortal1 = playerDimension.getEntities({name:portalName, type:"pg:portal_b"})
						const oldBluePortal2 = playerDimension.getEntities({name:portalName, type:"pg:portal_b_glados"})
						const oldBluePortal3 = playerDimension.getEntities({name:portalName, type:"pg:portal_b_rnm"})
						const oldBluePortal = oldBluePortal1.concat(oldBluePortal2, oldBluePortal3)
						oldBluePortal.forEach(oldPortalEntity => {
							oldPortalEntity.remove()
						});
						spawnedPortalEntity = playerDimension.spawnEntity("pg:portal_b", bulletLocation)					
					}else if(entityID.includes("bullet_o")){
						const oldOrangePortal1 = playerDimension.getEntities({name:portalName, type:"pg:portal_o"})
						const oldOrangePortal2 = playerDimension.getEntities({name:portalName, type:"pg:portal_o_glados"})
						const oldOrangePortal3 = playerDimension.getEntities({name:portalName, type:"pg:portal_o_rnm"})
						const oldOrangePortal = oldOrangePortal1.concat(oldOrangePortal2, oldOrangePortal3)
						oldOrangePortal.forEach(oldPortalEntity => {
							oldPortalEntity.remove()
						});
						spawnedPortalEntity = playerDimension.spawnEntity("pg:portal_o", bulletLocation)
					}
				}else if(entityID.includes("glados")){
					if(entityID.includes("bullet_b")){
						const oldBluePortal1 = playerDimension.getEntities({name:portalName, type:"pg:portal_b"})
						const oldBluePortal2 = playerDimension.getEntities({name:portalName, type:"pg:portal_b_glados"})
						const oldBluePortal3 = playerDimension.getEntities({name:portalName, type:"pg:portal_b_rnm"})
						const oldBluePortal = oldBluePortal1.concat(oldBluePortal2, oldBluePortal3)
						oldBluePortal.forEach(oldPortalEntity => {
							oldPortalEntity.remove()
						});
						spawnedPortalEntity = playerDimension.spawnEntity("pg:portal_b_glados", bulletLocation)					
					}else if(entityID.includes("bullet_o")){
						const oldOrangePortal1 = playerDimension.getEntities({name:portalName, type:"pg:portal_o"})
						const oldOrangePortal2 = playerDimension.getEntities({name:portalName, type:"pg:portal_o_glados"})
						const oldOrangePortal3 = playerDimension.getEntities({name:portalName, type:"pg:portal_o_rnm"})
						const oldOrangePortal = oldOrangePortal1.concat(oldOrangePortal2, oldOrangePortal3)
						oldOrangePortal.forEach(oldPortalEntity => {
							oldPortalEntity.remove()
						});
						spawnedPortalEntity = playerDimension.spawnEntity("pg:portal_o_glados", bulletLocation)
					}
				}else{
					if(entityID.includes("bullet_b")){
						const oldBluePortal1 = playerDimension.getEntities({name:portalName, type:"pg:portal_b"})
						const oldBluePortal2 = playerDimension.getEntities({name:portalName, type:"pg:portal_b_glados"})
						const oldBluePortal3 = playerDimension.getEntities({name:portalName, type:"pg:portal_b_rnm"})
						const oldBluePortal = oldBluePortal1.concat(oldBluePortal2, oldBluePortal3)
						oldBluePortal.forEach(oldPortalEntity => {
							oldPortalEntity.remove()
						});
						spawnedPortalEntity = playerDimension.spawnEntity("pg:portal_b_rnm", bulletLocation)					
					}else if(entityID.includes("bullet_o")){
						const oldOrangePortal1 = playerDimension.getEntities({name:portalName, type:"pg:portal_o"})
						const oldOrangePortal2 = playerDimension.getEntities({name:portalName, type:"pg:portal_o_glados"})
						const oldOrangePortal3 = playerDimension.getEntities({name:portalName, type:"pg:portal_o_rnm"})
						const oldOrangePortal = oldOrangePortal1.concat(oldOrangePortal2, oldOrangePortal3)
						oldOrangePortal.forEach(oldPortalEntity => {
							oldPortalEntity.remove()
						});
						spawnedPortalEntity = playerDimension.spawnEntity("pg:portal_o_rnm", bulletLocation)
					}
				}			
				spawnedPortalEntity.getComponent(EntityTameableComponent.componentId).tame(owner)
				spawnedPortalEntity.setRotation({x:0,y:rotation})
				spawnedPortalEntity.nameTag = portalName
				entity.remove()
			},5)
		}else{
			entity.remove()
		}
	}
})

world.afterEvents.entitySpawn.subscribe((event)=>{
	const {cause, entity} = event
	if(cause === EntityInitializationCause.Spawned){
		const entityID = entity.typeId
		const pgPortalRegex = /pg:.*portal/
		if(entityID.match(pgPortalRegex)){
			const owner = entity.getComponent(EntityTameableComponent.componentId).tamedToPlayer
			const portalEntryObject = pgUtils.getPortalEntry(owner.id, portalList)
			if (entityID.includes("_b")) {
				portalEntryObject.bluePortal = entity;
			} else if (entityID.includes("_o")) {
				portalEntryObject.orangePortal = entity;
			}
			portalList = pgUtils.setPortalEntry(portalEntryObject, portalList)
			portalList = pgUtils.validatePortals(portalList)
		}
	}
})

world.afterEvents.entityDie.subscribe((event)=>{
	const {damageSource, deadEntity} = event
	const cause = damageSource.cause
	if(cause === EntityDamageCause.selfDestruct){
		const entityID = deadEntity.typeId
		const pgPortalRegex = /pg:.*portal/
		if(entityID.match(pgPortalRegex)){
			const owner = deadEntity.getComponent(EntityTameableComponent.componentId).tamedToPlayer
			portalList = pgUtils.removePortal(owner.id, deadEntity, portalList)
		}
	}
})


world.afterEvents.worldInitialize.subscribe(()=>{
	system.runTimeout(()=>{
		world.sendMessage(`§l§e[Portal Gun] Addon Active.`)
		console.warn(`§l§e[Portal Gun] Addon Active.`)
		portalList = pgUtils.initializePortals(portalList)
	},60)
})

system.runTimeout(()=>{
	system.runInterval(()=>{
		portalList.forEach((portalObj)=>{
			let portalEntities = []
			if(portalObj.orangePortal) portalEntities.push(portalObj.orangePortal)
			if(portalObj.bluePortal) portalEntities.push(portalObj.bluePortal)			
			portalEntities.forEach((portalEntity)=>{
				const portalDimension = portalEntity.dimension			
				const portalLocation = portalEntity.location
				portalLocation.y += 0.2
				const EntitiesToTeleport = portalDimension.getEntities({excludeFamilies:["pg"],location:portalLocation, maxDistance: 0.6})
				let portalToTeleportTo = pgUtils.getPartnerPortal(portalEntity, portalObj)
				if(portalToTeleportTo){
					EntitiesToTeleport.forEach((entity)=>{
						const portalViewDirection = portalToTeleportTo.getViewDirection()
						const targetPortalRotation = portalToTeleportTo.getRotation()
						const targetPortalLocation = portalToTeleportTo.location
						targetPortalLocation.x += portalViewDirection.x*0.7
						targetPortalLocation.z += portalViewDirection.z*0.7
						const targetPortalDimension = portalToTeleportTo.dimension
						if(entity.typeId != "minecraft:player"){
							entity.teleport(targetPortalLocation, {dimension:targetPortalDimension, rotation:targetPortalRotation, keepVelocity:true})
						}else{
							entity.teleport(targetPortalLocation, {dimension:targetPortalDimension, rotation:targetPortalRotation})
							system.runTimeout(()=>{
								entity.playSound("gun.teleport", targetPortalLocation)
							},2)							
						}
					})
				}			
			})
		},5)
	})
},60)

system.afterEvents.scriptEventReceive.subscribe((event)=>{
	const {id, sourceEntity} = event
	switch(id){
		case "pg:list":
			sourceEntity.sendMessage(`§a[Portal Gun] ${JSON.stringify(portalList)}`)
		break;

		case "pg:refresh":
			portalList = pgUtils.initializePortals(portalList)
			sourceEntity.sendMessage(`§a[Portal Gun] Portals Refreshed`)
		break;
	}
})